$("#daycare").click(function(){
    $("#daycare_info").slideToggle("slow","linear");
});

$("#boarding").click(function(){
    $("#boarding_info").slideToggle("slow","linear");
});

$("#grooming").click(function(){
    $("#grooming_info").slideToggle("slow","linear");
});

$("#training").click(function(){
    $("#training_info").slideToggle("slow","linear");
});
